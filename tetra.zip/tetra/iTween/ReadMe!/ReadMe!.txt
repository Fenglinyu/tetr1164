iTween can be used with all scripting languages that Unity supports including JavaScript, C# and Boo. To install iTween create a folder named "Plugins" in your project's assets (if you are using C# the location of iTween does not matter as long as it is inside your assets folder).

For complete documentation, examples and information visit: http://itween.pixelplacement.com